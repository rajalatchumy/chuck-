package fr.isep.chuck;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class QuoteActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quote);
        refresh(null);
    }

    public void refresh(View view) {
        TextView quote = (TextView) findViewById(R.id.quote);
        String url = "https://api.chucknorris.io/jokes/random";
        RequestQueue queue = Volley.newRequestQueue(this);

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest
                (Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            quote.setText(response.get("value").toString());
                        } catch (JSONException exception) {
                            Log.e("quote", "get value ko");
                        }
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        quote.setText("Bonjour");
                    }
                });

        queue.add(jsonObjectRequest);
        queue.start();
    }

    public void share(View view) {
        Toast.makeText(this, "C'MON DO SOMETHING !", Toast.LENGTH_SHORT).show();
        // TODO
    }
}